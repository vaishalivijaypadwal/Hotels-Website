// src/pages/Kinara/About.jsx
export default function KinaraAbout() {
  return (
    <div className="resort-page">
      <h1>About Kinara Resort</h1>
      <div className="about-content">
       
      </div>
    </div>
  );
}